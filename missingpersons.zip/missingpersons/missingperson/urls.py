from django.urls import path
from .views import indexPageView
from .views import personsPageView

#Created the paths and names to set up the correct routes to each page
urlpatterns = [
  path("persons/", personsPageView, name= "persons"),
  path("", indexPageView, name="index"),
]