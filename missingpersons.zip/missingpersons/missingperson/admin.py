from django.contrib import admin
from .models import MissingPerson
# Register your models here.

#Registered my created model
admin.site.register(MissingPerson)