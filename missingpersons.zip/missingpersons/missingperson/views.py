from django.shortcuts import render
from .models import MissingPerson

# Create your views here.
# Used the JSON data in a list and context to pass this to the template and have it render the data

def indexPageView(request) :
  return render(request, 'missingperson/index.html')  

def personsPageView(request) :
    data = MissingPerson.objects.all() 
    context = {
            "data" : data
    }
    return render(request, 'missingperson/persons.html', context)


